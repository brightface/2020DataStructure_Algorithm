#include <vector>
#include <stack>
#include <list>
using namespace std;

int main()
{
	vector<int> v;
	stack<int> s;
	stack<int, vector<int>> sv;
	stack<int, list<int>> sl;

	return 0;
}