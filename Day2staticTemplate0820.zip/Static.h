#pragma once

class Static
{
public:
	Static();
	~Static();

	//static void CheckIntesect(Static* a, Static* b);

	static void Function();
	void Function2();
	static int value4;
	//virtual void Function3();
private:
	int value2;
	int value3;
};




